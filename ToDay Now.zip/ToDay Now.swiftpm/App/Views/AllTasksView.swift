import SwiftUI

struct AllTasksView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(
        entity: TaskData.entity(),
        sortDescriptors: [
            NSSortDescriptor(keyPath: \TaskData.taskPriorityNumber, ascending: false)
        ])
    var tasks: FetchedResults<TaskData>
    
    @State var showError: Bool = false
    
    var body: some View {
        
        ScrollView {
            
            ForEach(tasks) { task in
                
                NavigationLink(destination: EditTaskView(task: task)) {
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50)
                            .foregroundColor(Color(.systemGray5))
                        
                        HStack {
                            
                            if task.taskSymbol.count > 0 {
                                Image(systemName: task.taskSymbol)
                                    .font(.system(size: 17.5))
                                    .foregroundColor(Color(UIColor(red: CGFloat(task.taskColorRed), green: CGFloat(task.taskColorGreen), blue: CGFloat(task.taskColorBlue), alpha: CGFloat(task.taskColorAlpha))))
                            }
                            
                            VStack {
                                
                                HStack {
                                    
                                    Text(task.taskName)
                                        .bold()
                                        .font(.system(size: 17.5))
                                        .foregroundColor(colorScheme == .dark ? .white : .black)
                                    
                                    Spacer()
                                }
                                
                                if task.taskCategory.count > 0 {
                                    HStack {
                                        Text("\(task.taskCategory) - \(task.taskSubCategory)")
                                            .font(.system(size: 15))
                                            .foregroundColor(.gray)
                                        Spacer()
                                    }
                                }
                                
                            }
                            
                            Spacer()
                            
                            Button {
                                task.taskComplete.toggle()
                                do {
                                    try managedObjectContext.save()
                                } catch {
                                    let nsError = error as NSError
                                    print(nsError.localizedDescription)
                                    showError = true
                                }
                            } label: {
                                Image(systemName: task.taskComplete ? "checkmark.circle.fill" : "circle")
                                    .font(.system(size: 17.5))
                                    .foregroundColor(task.taskPriority.taskPriorityColor())
                            }
                            .alert(isPresented: $showError) {
                                Alert(title: Text("Error"), message: Text("Failed to update data."), dismissButton: .default(Text("Ok")))
                            }
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    .contextMenu {
                        Text("\(task.taskDate, style: .time) - \(task.taskDate, style: .date)")
                    }
                    
                }
                
            }
            
        }
        
    }
}
