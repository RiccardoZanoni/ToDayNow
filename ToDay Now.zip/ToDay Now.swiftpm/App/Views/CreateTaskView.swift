import SwiftUI

struct CreateTaskView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.managedObjectContext) var managedObjectContext
    @Environment(\.presentationMode) var presentationMode
    @ObservedObject var notifications: Notifications = Notifications()
    
    @State var taskName: String = ""
    @State var taskCategory: String = ""
    @State var taskSubCategory: String = ""
    @State var taskSymbol: String = ""
    @State var taskPriority: TaskPriority = .normal
    @State var taskColor: Color = .blue
    @State var taskDate: Date = Date()
    @State var taskComplete: Bool = false
    
    @State var toSelectColorSymbolView: Bool = false
    @State var categorySubCategoryNotification: Bool = false
    @State var showError: Bool = false
    
    var body: some View {
            
            NavigationView {
                
                ScrollView {
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Name", text: $taskName)
                            .padding(.horizontal, 30)
                            .font(.system(size: 17.5))
                            .accentColor(.blue)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Category", text: $taskCategory)
                            .padding(.horizontal, 30)
                            .font(.system(size: 17.5))
                            .accentColor(.blue)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Sub category", text: $taskSubCategory)
                            .padding(.horizontal, 30)
                            .font(.system(size: 17.5))
                            .accentColor(.blue)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        HStack {
                            
                            Button {
                                toSelectColorSymbolView.toggle()
                            } label: {
                                Text("Select color & symbol")
                                    .padding(.leading, 30)
                                    .font(.system(size: 17.5))
                                    .foregroundColor(.blue)
                            }
                            .sheet(isPresented: $toSelectColorSymbolView) {
                                ColorsSymbolsView(colorSelect: $taskColor, symbolSelect: $taskSymbol)
                            }
                            
                            Spacer()
                            
                            Image(systemName: taskSymbol)
                                .padding(.trailing, 30)
                                .foregroundColor(taskColor)
                            
                        }
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        HStack {
                            
                            Text("Priority")
                                .font(.system(size: 17.5))
                                .foregroundColor(taskPriority.taskPriorityColor())
                            
                            Spacer()
                            
                            Menu {
                                
                                Picker("", selection: $taskPriority) {
                                    
                                    Text("Normal")
                                        .tag(TaskPriority.normal)
                                    
                                    Text("Low")
                                        .tag(TaskPriority.low)
                                    
                                    Text("Medium")
                                        .tag(TaskPriority.medium)
                                    
                                    Text("High")
                                        .tag(TaskPriority.high)
                                    
                                }
                                
                            } label: {
                                Text(taskPriority.taskPriorityName())
                                    .font(.system(size: 17.5))
                                    .foregroundColor(.blue)
                            }
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        DatePicker("Date", selection: $taskDate)
                            .padding(.horizontal, 30)
                            .accentColor(.blue)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        Toggle(isOn: $taskComplete) {
                            Text("Completed")
                                .font(.system(size: 17.5))
                        }
                        .padding(.horizontal, 30)
                        .tint(.blue)
                        
                    }
                    
                }
                    
                .navigationTitle("Create task")
                .navigationBarTitleDisplayMode(.inline)
                .navigationBarItems(leading: cancelButton, trailing: addButton)
            }
            .navigationViewStyle(.stack)
        
    }
    
    var cancelButton: some View {
        Button {
            presentationMode.wrappedValue.dismiss()
        } label: {
            Text("Cancel")
                .foregroundColor(.blue)
        }
    }
    
    var addButton: some View {
        Button {
            if taskName.count > 0 {
                if taskCategory.count > 0 && taskSubCategory.count > 0 {
                    createTask(category: taskCategory, subCategory: taskSubCategory)
                } else {
                    createTask(category: "", subCategory: "")
                }
            }
        } label: {
            if taskName.count == 0 {
                Text("Create")
                    .bold()
                    .foregroundColor(.gray)
            } else if taskName.count > 0 {
                if taskCategory.count > 0 && taskSubCategory.count > 0 {
                    Text("Create")
                        .bold()
                        .foregroundColor(.blue)
                } else {
                    Text("Create")
                        .bold()
                        .foregroundColor(.blue)
                }
            }
        }
        .alert(isPresented: $showError) {
            Alert(title: Text("Error"), message: Text("Failed to save data."), dismissButton: .default(Text("Ok")))
        }
    }
    
    func createTask(category: String, subCategory: String) {
        
        let task = TaskData(context: managedObjectContext)
        let color: UIColor = UIColor(taskColor)
        task.taskId = UUID()
        task.taskName = taskName
        task.taskCategory = category
        task.taskSubCategory = subCategory
        task.taskSymbol = taskSymbol
        task.taskColorRed = Float(color.components.red)
        task.taskColorGreen = Float(color.components.green)
        task.taskColorBlue = Float(color.components.blue)
        task.taskColorAlpha = Float(color.components.alpha)
        task.taskPriority = taskPriority 
        task.taskDate = taskDate
        task.taskComplete = taskComplete
        
        if taskCategory.count > 0 {
            categorySubCategoryNotification = true
        }
            
        if taskDate > .now {
            let dateComponents = Calendar.current.dateComponents([.day, .hour, .minute], from: taskDate)
            guard let day = dateComponents.day, let hour = dateComponents.hour, let minute = dateComponents.minute else { return }
            notifications.createLocalNotification(title: taskName, details: categorySubCategoryNotification ? "\(taskCategory) - \(taskSubCategory)" : "", day: day, hour: hour, minute: minute) { _ in }
        }
        
        do {
            try managedObjectContext.save()
            if taskDate > .now {
                notifications.reloadLocalNotifications()
            }
            presentationMode.wrappedValue.dismiss()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
            showError = true
        }
        
    }
    
}
