import SwiftUI

struct EditTaskView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) var managedObjectContext
    @ObservedObject var task: TaskData
    
    @State var taskName: String
    @State var taskCategory: String
    @State var taskSubCategory: String
    @State var taskPriority: TaskPriority
    @State var taskComplete: Bool
    
    init(task: TaskData) {
        self.task = task
        self._taskName = State(initialValue: task.taskName)
        self._taskCategory = State(initialValue: task.taskCategory)
        self._taskSubCategory = State(initialValue: task.taskSubCategory)
        self._taskPriority = State(initialValue: task.taskPriority)
        self._taskComplete = State(initialValue: task.taskComplete)
    }
    
    @State var toSelectColorSymbolView: Bool = false
    
    var body: some View {
        
        ScrollView {
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(taskName.count > 0 ? taskName : "Name", text: $taskName)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(taskCategory.count > 0 ? taskCategory : "Category", text: $taskCategory)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(taskSubCategory.count > 0 ? taskSubCategory : "Sub category", text: $taskSubCategory)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Priority")
                        .font(.system(size: 17.5))
                        .foregroundColor(taskPriority.taskPriorityColor())
                    
                    Spacer()
                    
                    Menu {
                        
                        Picker("", selection: $taskPriority) {
                            
                            Text("Normal")
                                .font(.system(size: 25))
                                .tag(TaskPriority.normal)
                            
                            Text("Low")
                                .tag(TaskPriority.low)
                            
                            Text("Medium")
                                .tag(TaskPriority.medium)
                            
                            Text("High")
                                .tag(TaskPriority.high)
                            
                        }
                        
                    } label: {
                        Text(taskPriority.taskPriorityName())
                            .font(.system(size: 17.5))
                            .foregroundColor(.blue)
                    }
                    
                }
                .padding(.horizontal, 30)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                Toggle(isOn: $taskComplete) {
                    Text("Completed")
                        .font(.system(size: 17.5))
                }
                .padding(.horizontal, 30)
                .tint(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Button {
                        deleteTask()
                    } label: {
                        Label("Delete task", systemImage: "trash")
                            .padding(.leading, 30)
                            .foregroundColor(.red)
                    }
                    
                    Spacer()
                }
                
            }
            
        }
        
        .navigationTitle("Edit task")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(trailing: saveButton)
        
    }
    
    var saveButton: some View {
        Button {
            if taskName.count > 0 {
                if taskCategory.count > 0 && taskSubCategory.count > 0 {
                    saveTask(category: taskCategory, subCategory: taskSubCategory)
                } else {
                    saveTask(category: "", subCategory: "")
                }
            }
        } label: {
            if taskName.count > 0 {
                Text("Save")
                    .bold()
                    .foregroundColor(.blue)
            } else {
                Text("Save")
                    .bold()
                    .foregroundColor(.gray)
            }
        }
    }
    
    func saveTask(category: String, subCategory: String) {
        
        task.taskId = UUID()
        task.taskName = taskName
        task.taskCategory = category
        task.taskSubCategory = subCategory
        task.taskPriority = taskPriority
        task.taskComplete = taskComplete
        
        do {
            try managedObjectContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
        }
        
    }
    
    func deleteTask() {
        managedObjectContext.delete(task)
        do {
            try managedObjectContext.save()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
        }
    }
    
}
