import SwiftUI

struct TasksView: View {
    
    @FetchRequest(
        entity: TaskData.entity(), 
        sortDescriptors: [
            NSSortDescriptor(keyPath: \TaskData.taskName, ascending: true)
        ])
    var tasks: FetchedResults<TaskData>
    
    @ObservedObject var notifications: Notifications = Notifications()
    
    @State var toCreateTaskView: Bool = false
    @State var toDeleteTaskView: Bool = false
    @State var viewSelect: Int = 0
    
    var body: some View {
        
        NavigationView {
            
            ScrollView {
                
                VStack {
                    
                    Picker("", selection: $viewSelect) {
                        
                        Image(systemName: "checklist")
                            .tag(0)
                        
                        Image(systemName: "circle")
                            .tag(1)
                        
                        Image(systemName: "checkmark.circle.fill")
                            .tag(2)
                        
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal, 15)
                    
                    Spacer(minLength: 17.5)
                    
                    if viewSelect == 0 {
                        AllTasksView()
                    } else if viewSelect == 1 {
                        NotCompleteTasksView()
                    } else {
                        CompleteTasksView()
                    }
                    
                }
                
            }
            
            .navigationTitle("Tasks")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    plusButton
                }
            }
            
            .onAppear(perform: notifications.reloadAuthorizationStatus)
            .onChange(of: notifications.authorizationStatus) { authorizationStatus in
                switch authorizationStatus {
                case .notDetermined:
                    notifications.requestAuthorization()
                case .authorized:
                    notifications.reloadLocalNotifications()
                default:
                    break
                }
            }
            .onReceive(NotificationCenter.default.publisher(for: UIApplication.willEnterForegroundNotification)) { _ in
                notifications.reloadAuthorizationStatus()
            }
            
        }
        .navigationViewStyle(.stack)
        
    }
    
    var plusButton: some View {
        Button {
            toCreateTaskView.toggle()
        } label: {
            Image(systemName: "plus")
                .foregroundColor(.blue)
        }
        .sheet(isPresented: $toCreateTaskView) {
            CreateTaskView()
        }
    }
    
}
