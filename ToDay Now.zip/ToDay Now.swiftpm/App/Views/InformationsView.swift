import SwiftUI

struct InformationsView: View {
    var body: some View {
        
        ScrollView {
            
            VStack {
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    HStack {
                        
                        Text("Version")
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                        Text("1.1.0")
                            .foregroundColor(.gray)
                        
                    }
                    .padding(.horizontal, 30)
                    
                }
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    HStack {
                        
                        Text("App")
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                        Text("Swift Playgrounds")
                            .foregroundColor(.gray)
                        
                    }
                    .padding(.horizontal, 30)
                    
                }
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    HStack {
                        
                        Text("Programming lenguage")
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                        Text("Swift")
                            .foregroundColor(.gray)
                        
                    }
                    .padding(.horizontal, 30)
                    
                }
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    NavigationLink(destination: FrameworksView()) {
                        
                        HStack {
                            
                            Label("Frameworks", systemImage: "rectangle.3.group.fill")
                                .foregroundColor(.blue)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .foregroundColor(.blue)
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    
                }
                
                Spacer()
            }
            
        }
        
        .navigationTitle("Informations")
        .navigationBarTitleDisplayMode(.inline)
        
    }
}
