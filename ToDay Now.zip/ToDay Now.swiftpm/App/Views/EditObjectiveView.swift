import SwiftUI

struct EditObjectiveView: View {
    
    @Environment(\.presentationMode) var presentationMode
    @Environment(\.managedObjectContext) var managedObjectContext
    @ObservedObject var objective: ObjectiveData
    
    @State var objectiveName: String
    @State var objectiveCategory: String
    @State var objectiveSubCategory: String
    @State var objectiveObject: String
    
    init(objective: ObjectiveData) {
        self.objective = objective
        self._objectiveName = State(initialValue: objective.objectiveName)
        self._objectiveCategory = State(initialValue: objective.objectiveCategory)
        self._objectiveSubCategory = State(initialValue: objective.objectiveSubCategory)
        self._objectiveObject = State(initialValue: objective.objectiveObject)
    }
    
    var body: some View {
        
        ScrollView {
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(objectiveName.count > 0 ? objectiveName : "Name", text: $objectiveName)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(objectiveCategory.count > 0 ? objectiveCategory : "Category", text: $objectiveCategory)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(objectiveSubCategory.count > 0 ? objectiveSubCategory : "Sub category", text: $objectiveSubCategory)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                TextField(objectiveObject.count > 0 ? objectiveObject : "Object", text: $objectiveObject)
                    .padding(.horizontal, 30)
                    .font(.system(size: 17.5))
                    .accentColor(.blue)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Button {
                        deleteObjective()
                    } label: {
                        Label("Delete objective", systemImage: "trash")
                            .padding(.leading, 30)
                            .foregroundColor(.red)
                    }
                    
                    Spacer()
                }
                
            }
            
        }
        
        .navigationTitle("Edit objective")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarItems(trailing: saveButton)
        
    }
    
    var saveButton: some View {
        Button {
            if objectiveName.count > 0 {
                if objectiveCategory.count > 0 && objectiveSubCategory.count > 0 {
                    saveObjective(category: objectiveCategory, subCategory: objectiveSubCategory)
                } else {
                    saveObjective(category: "", subCategory: "")
                }
            }
        } label: {
            if objectiveName.count > 0 {
                Text("Save")
                    .bold()
                    .foregroundColor(.blue)
            } else {
                Text("Save")
                    .bold()
                    .foregroundColor(.gray)
            }
        }
    }
    
    func saveObjective(category: String, subCategory: String) {
        
        objective.objectiveId = UUID()
        objective.objectiveName = objectiveName
        objective.objectiveCategory = category
        objective.objectiveSubCategory = subCategory
        objective.objectiveObject = objectiveObject
        
        do {
            try managedObjectContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
        }
        
    }
    
    func deleteObjective() {
        managedObjectContext.delete(objective)
        do {
            try managedObjectContext.save()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
        }
    }
    
}
