import SwiftUI

struct ObjectivesView: View {
    
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.managedObjectContext) var managedObjectContext
    @FetchRequest(
        entity: ObjectiveData.entity(),
        sortDescriptors: [
            NSSortDescriptor(keyPath: \ObjectiveData.objectiveComplete, ascending: true)
        ])
    var objectives: FetchedResults<ObjectiveData>
    
    @State var toCreateObjectiveView: Bool = false
    @State var showError: Bool = false
    
    var body: some View {
        
        NavigationView {
            
            ScrollView {
                
                ForEach(objectives) { objective in
                    
                    NavigationLink(destination: EditObjectiveView(objective: objective)) {
                        
                        ZStack {
                            
                            RoundedRectangle(cornerRadius: 10)
                                .padding(.horizontal, 15)
                                .frame(width: .infinity, height: 50)
                                .foregroundColor(Color(.systemGray5))
                            
                            HStack {
                                
                                ZStack {
                                    
                                    if objective.objectiveComplete == false {
                                        Circle()
                                            .trim(from: 0, to: CGFloat(objective.objectiveStatusTrim))
                                            .stroke(lineWidth: 2)
                                            .rotationEffect(.init(degrees: -90))
                                            .frame(width: 40, height: 40)
                                            .foregroundColor(Color(UIColor(red: CGFloat(objective.objectiveColorRed), green: CGFloat(objective.objectiveColorGreen), blue: CGFloat(objective.objectiveColorBlue), alpha: CGFloat(objective.objectiveColorAlpha))))
                                    }
                                    
                                    Image(systemName: objective.objectiveSymbol)
                                        .font(.system(size: 17.5))
                                        .foregroundColor(Color(UIColor(red: CGFloat(objective.objectiveColorRed), green: CGFloat(objective.objectiveColorGreen), blue: CGFloat(objective.objectiveColorBlue), alpha: CGFloat(objective.objectiveColorAlpha))))
                                    
                                }
                                
                                VStack {
                                    
                                    HStack {
                                        
                                        Text(objective.objectiveName)
                                            .bold()
                                            .font(.system(size: 17.5))
                                            .foregroundColor(colorScheme == .dark ? .white : .black)
                                        
                                        Spacer()
                                    }
                                    
                                    if objective.objectiveCategory.count > 0 {
                                        HStack {
                                            
                                            Text("\(objective.objectiveCategory) - \(objective.objectiveSubCategory)")
                                                .font(.system(size: 15))
                                                .foregroundColor(.gray)
                                            
                                            Spacer()
                                        }
                                    }
                                    
                                }
                                
                                Spacer()
                                
                                if objective.objectiveComplete {
                                    
                                    Image(systemName: "checkmark.circle.fill")
                                        .font(.system(size: 17.5))
                                        .foregroundColor(.gray)
                                    
                                } else {
                                    
                                    Button {
                                        withAnimation {
                                            if objective.objectiveStatus > 0 {
                                                objective.objectiveStatusTrim -= objective.objectiveOnRemoveTrim
                                                objective.objectiveStatus -= objective.objectiveOnRemove
                                            }
                                            do {
                                                try managedObjectContext.save()
                                            } catch {
                                                let nsError = error as NSError
                                                print(nsError.localizedDescription)
                                            }
                                        }
                                    } label: {
                                        if objective.objectiveStatus > 0 {
                                            Image(systemName: "minus.circle.fill")
                                                .font(.system(size: 17.5))
                                                .foregroundColor(.blue)
                                        } else {
                                            Image(systemName: "minus.circle.fill")
                                                .font(.system(size: 17.5))
                                                .foregroundColor(.gray)
                                        }
                                    }
                                    .alert(isPresented: $showError) {
                                        Alert(title: Text("Error"), message: Text("Failed to update data."), dismissButton: .default(Text("Ok")))
                                    }
                                    
                                    Spacer(minLength: 10)
                                    
                                    Button {
                                        withAnimation {
                                            objective.objectiveStatusTrim += objective.objectiveOnAddTrim
                                            objective.objectiveStatus += objective.objectiveOnAdd
                                            if objective.objectiveStatus >= objective.objectiveEnd {
                                                objective.objectiveComplete = true
                                                objective.objectiveStatus = objective.objectiveEnd
                                            }
                                            do {
                                                try managedObjectContext.save()
                                            } catch {
                                                let nsError = error as NSError
                                                print(nsError.localizedDescription)
                                            }
                                        }
                                    } label: {
                                        Image(systemName: "plus.circle.fill")
                                            .font(.system(size: 17.5))
                                    }
                                    .alert(isPresented: $showError) {
                                        Alert(title: Text("Error"), message: Text("Failed to update data."), dismissButton: .default(Text("Ok")))
                                    }
                                    
                                }
                                
                            }
                            .padding(.horizontal, 30)
                            
                        }
                        .contextMenu {
                            Text("\(objective.objectiveStatus.formatted()) of \(objective.objectiveEnd.formatted()) \(objective.objectiveObject)")
                        }
                        
                    }
                    
                }
                
            }
            
            .navigationTitle("Objectives")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    plusButton
                }
            }
        }
        .navigationViewStyle(.stack)
        
    }
    
    var plusButton: some View {
        Button {
            toCreateObjectiveView.toggle()
        } label: {
            Image(systemName: "plus")
                .foregroundColor(.blue)
        }
        .sheet(isPresented: $toCreateObjectiveView) {
            CreateObjectiveView()
        }
    }
    
}
