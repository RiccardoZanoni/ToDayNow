import SwiftUI

struct PrivacyView: View {
    var body: some View {
        
        ScrollView {
            
            VStack {
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    HStack {
                        
                        Text("ToDay will never read your data.")
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                    }
                    .padding(.horizontal, 30)
                    
                }
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    HStack {
                        
                        Text("All your data is saved on your device.")
                            .foregroundColor(.gray)
                        
                        Spacer()
                        
                    }
                    .padding(.horizontal, 30)
                    
                }
                
                Spacer()
            }
            
        }
        
        .navigationTitle("Privacy")
        .navigationBarTitleDisplayMode(.inline)
        
    }
    
}
