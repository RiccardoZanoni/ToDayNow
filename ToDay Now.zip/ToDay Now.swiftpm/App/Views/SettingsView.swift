import SwiftUI

struct SettingsView: View {
    var body: some View {
        
        NavigationView {
            
            ScrollView {
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    NavigationLink(destination: PrivacyView()) {
                        
                        HStack {
                            
                            Label("Privacy", systemImage: "hand.raised.fill")
                                .font(.system(size: 17.5))
                                .foregroundColor(.blue)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .font(.system(size: 17.5))
                                .foregroundColor(.blue)
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    
                }
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    NavigationLink(destination: ContactMeView()) {
                        
                        HStack {
                            
                            Label("Contact me", systemImage: "person.fill")
                                .font(.system(size: 17.5))
                                .foregroundColor(.blue)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .font(.system(size: 17.5))
                                .foregroundColor(.blue)
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    
                }
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 10)
                        .padding(.horizontal, 15)
                        .frame(width: .infinity, height: 50, alignment: .top)
                        .foregroundColor(Color(.systemGray5))
                    
                    NavigationLink(destination: InformationsView()) {
                        
                        HStack {
                            
                            Label("Informations", systemImage: "info.circle.fill")
                                .font(.system(size: 17.5))
                                .foregroundColor(.blue)
                            
                            Spacer()
                            
                            Image(systemName: "chevron.right")
                                .font(.system(size: 17.5))
                                .foregroundColor(.blue)
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    
                }
                
            }
            
            .navigationTitle("Settings")
        }
        .navigationViewStyle(.stack)
        
    }
}
