import SwiftUI

struct FrameworksView: View {
    var body: some View {
        
        ScrollView {
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Main")
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("SwiftUI")
                        .foregroundColor(.gray)
                    
                }
                .padding(.horizontal, 30)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Design")
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("SwiftUI")
                        .foregroundColor(.gray)
                    
                }
                .padding(.horizontal, 30)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Data")
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("CoreData")
                        .foregroundColor(.gray)
                    
                }
                .padding(.horizontal, 30)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 15)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Notifications")
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("UserNotifications")
                        .foregroundColor(.gray)
                    
                }
                .padding(.horizontal, 30)
                
            }
            
        }
        
        .navigationTitle("Frameworks")
        .navigationBarTitleDisplayMode(.inline)
        
    }
}
