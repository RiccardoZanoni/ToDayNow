import SwiftUI
import Combine

struct CreateObjectiveView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    @Environment(\.presentationMode) var presentationMode
    
    @State var objectiveName: String = ""
    @State var objectiveCategory: String = ""
    @State var objectiveSubCategory: String = ""
    @State var objectiveOnRemove: String = ""
    @State var objectiveOnAdd: String = ""
    @State var objectiveObject: String = ""
    @State var objectiveEnd: String = ""
    @State var objectiveSymbol: String = ""
    @State var objectiveColor: Color = .blue
    @State var objectiveComplete: Bool = false
    
    @State var toColorsSymbolsView: Bool = false
    @State var showError: Bool = false
    
    var body: some View {
        
        NavigationView {
            
            ScrollView {
                
                VStack {
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Name", text: $objectiveName)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Category", text: $objectiveCategory)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Sub category", text: $objectiveSubCategory)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("On remove", text: $objectiveOnRemove)
                            .keyboardType(.decimalPad)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                            .onReceive(Just(objectiveOnRemove)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue { objectiveOnRemove = filtered }
                            }
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("On add", text: $objectiveOnAdd)
                            .keyboardType(.decimalPad)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                            .onReceive(Just(objectiveOnAdd)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue { objectiveOnAdd = filtered }
                            }
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Objective", text: $objectiveEnd)
                            .keyboardType(.decimalPad)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                            .onReceive(Just(objectiveEnd)) { newValue in
                                let filtered = newValue.filter { "0123456789".contains($0) }
                                if filtered != newValue { objectiveEnd = filtered }
                            }
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        TextField("Object", text: $objectiveObject)
                            .padding(.horizontal, 30)
                            .foregroundColor(.white)
                        
                    }
                    
                    ZStack {
                        
                        RoundedRectangle(cornerRadius: 10)
                            .padding(.horizontal, 15)
                            .frame(width: .infinity, height: 50, alignment: .top)
                            .foregroundColor(Color(.systemGray5))
                        
                        HStack {
                            
                            Button {
                                toColorsSymbolsView.toggle()
                            } label: {
                                Text("Select color & symbol")
                                    .font(.system(size: 17.5))
                                    .foregroundColor(.blue)
                            }
                            .sheet(isPresented: $toColorsSymbolsView) {
                                ColorsSymbolsView(colorSelect: $objectiveColor, symbolSelect: $objectiveSymbol)
                            }
                            
                            Spacer()
                            
                            Image(systemName: objectiveSymbol)
                                .foregroundColor(objectiveColor)
                            
                        }
                        .padding(.horizontal, 30)
                        
                    }
                    
                }
                
            }
            
            .navigationTitle("Create objective")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: cancelButton, trailing: createButton)
        }
        
    }
    
    var cancelButton: some View {
        Button {
            presentationMode.wrappedValue.dismiss()
        } label: {
            Text("Cancel")
                .foregroundColor(.blue)
        }
    }
    
    var createButton: some View {
        Button {
            if objectiveName.count > 0 && objectiveSymbol.count > 0 && objectiveOnRemove.count > 0 && objectiveOnAdd.count > 0 && objectiveEnd.count > 0 && objectiveObject.count > 0 {
                if objectiveCategory.count > 0 && objectiveSubCategory.count > 0 {
                    createObjective(category: objectiveCategory, subCategory: objectiveSubCategory)
                } else {
                    createObjective(category: "", subCategory: "")
                }
            }
        } label: {
            if objectiveName.count > 0 && objectiveSymbol.count > 0 && objectiveOnRemove.count > 0 && objectiveOnAdd.count > 0 && objectiveEnd.count > 0 && objectiveObject.count > 0 {
                Text("Create")
                    .bold()
                    .foregroundColor(.blue)
            } else {
                Text("Create")
                    .bold()
                    .foregroundColor(.gray)
            }
        }
        .alert(isPresented: $showError) {
            Alert(title: Text("Error"), message: Text("Failed to save data."), dismissButton: .default(Text("Ok")))
        }
    }
    
    func createObjective(category: String, subCategory: String) {
        
        let objective: ObjectiveData = ObjectiveData(context: managedObjectContext)
        let color: UIColor = UIColor(objectiveColor)
        let objectiveOnRemoveFloat: Float = Float(objectiveOnRemove) ?? 0
        let objectiveOnAddFloat: Float = Float(objectiveOnAdd) ?? 0
        let objectiveEndFloat: Float = Float(objectiveEnd) ?? 0
        let objectiveOnRemoveTrim: Float = 1 / objectiveEndFloat * objectiveOnRemoveFloat
        let objectiveOnAddTrim: Float = 1 / objectiveEndFloat * objectiveOnAddFloat
        
        objective.objectiveId = UUID()
        objective.objectiveColorRed = Float(color.components.red)
        objective.objectiveColorGreen = Float(color.components.green)
        objective.objectiveColorBlue = Float(color.components.blue)
        objective.objectiveColorAlpha = Float(color.components.alpha)
        objective.objectiveName = objectiveName
        objective.objectiveCategory = category
        objective.objectiveSubCategory = subCategory
        objective.objectiveOnRemove = Float(objectiveOnRemove) ?? 0
        objective.objectiveOnAdd = Float(objectiveOnAdd) ?? 0
        objective.objectiveOnRemoveTrim = objectiveOnRemoveTrim
        objective.objectiveOnAddTrim = objectiveOnAddTrim
        objective.objectiveEnd = Float(objectiveEnd) ?? 0
        objective.objectiveObject = objectiveObject
        objective.objectiveSymbol = objectiveSymbol
        objective.objectiveComplete = objectiveComplete
        
        do {
            try managedObjectContext.save()
            presentationMode.wrappedValue.dismiss()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
            showError = true
        }
        
    }
    
}
