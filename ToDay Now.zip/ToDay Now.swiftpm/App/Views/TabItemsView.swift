import SwiftUI

struct TabItemsView: View {
    
    @Environment(\.managedObjectContext) var managedObjectContext
    
    var body: some View {
        
        TabView {
            
            TasksView()
                .tabItem {
                    Label("Tasks", systemImage: "note.text")
                }
            
            ObjectivesView()
                .tabItem {
                    Label("Objectives", systemImage: "arrow.clockwise.circle.fill")
                }
            
            SettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gear")
                }
            
        }
        
    }
}
