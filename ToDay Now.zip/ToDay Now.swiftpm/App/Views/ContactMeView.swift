import SwiftUI

struct ContactMeView: View {
    var body: some View {
        
        ScrollView {
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 5)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Every day")
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("12AM - 8PM (UTC+1)")
                        .foregroundColor(.gray)
                    
                }
                .padding(.horizontal, 20)
                
            }
            
            ZStack {
                
                RoundedRectangle(cornerRadius: 10)
                    .padding(.horizontal, 5)
                    .frame(width: .infinity, height: 50, alignment: .top)
                    .foregroundColor(Color(.systemGray5))
                
                HStack {
                    
                    Text("Mail")
                        .foregroundColor(.gray)
                    
                    Spacer()
                    
                    Text("todaynowappcontact@gmail.com")
                        .foregroundColor(.blue)
                    
                }
                .padding(.horizontal, 20)
                
            }
            
        }
        
        .navigationTitle("Contact me")
        .navigationBarTitleDisplayMode(.inline)
        
    }
}
