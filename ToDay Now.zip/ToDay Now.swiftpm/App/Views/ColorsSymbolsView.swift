import SwiftUI

struct ColorsSymbolsView: View {
    
    @Environment(\.presentationMode) var presentationMode
    
    @Binding var colorSelect: Color
    @Binding var symbolSelect: String
    
    let colorToSelect: [Color] = [
        .red,
        .orange,
        .yellow,
        .green,
        .mint,
        .cyan,
        .blue,
        .indigo,
        .purple,
        .pink
    ]
    
    let symbolToSelect: [String] = [
        "gift.fill",
        "envelope.fill",
        "car.fill",
        "atom",
        "bus.fill",
        "book.fill",
        "gamecontroller.fill",
        "video.fill",
        "pencil",
        "link",
        "umbrella.fill",
        "tv.fill",
        "house.fill",
        "airplane",
        "figure.walk",
        "clock.fill",
        "bag.fill",
        "graduationcap.fill",
        "person.3.fill",
        "briefcase.fill",
        "camera.fill",
        "mappin.and.ellipse",
        "fuelpump.fill", 
        "curlybraces",
        "arrow.3.trianglepath",
        "x.squareroot",
        "bed.double.fill",
        "crown.fill",
        "theatermasks.fill",
        "paintbrush.pointed.fill",
        "facemask.fill",
        "ferry.fill",
        "pianokeys.inverse",
        "sportscourt.fill",
        "building.fill",
        "fork.knife",
        "studentdesk",
        "binoculars.fill",
        "lightbulb.fill",
        "bandage.fill",
        "eyeglasses",
        "tag.fill",
        "music.mic",
        "cart.fill",
        "paintpalette.fill",
        "creditcard.fill",
        "banknote.fill",
        "scooter",
        "bicycle",
        "powersleep",
        "hammer.fill",
        "phone.fill",
        "scissors",
        "pills.fill",
        "newspaper.fill",
        "music.note",
        "map.fill",
        "radio.fill",
        "takeoutbag.and.cup.and.straw.fill",
        "chart.pie.fill",
        "key.fill",
        "stethoscope",
        "doc.fill",
        "building.columns.fill",
        "tshirt.fill"
    ]
    
    let columns: [GridItem] = [
        GridItem(.adaptive(minimum: 50))
    ]
    
    let rows: [GridItem] = [
        GridItem(.adaptive(minimum: 20))
    ]
    
    var body: some View {
        
        NavigationView {
            
            ScrollView {
                
                VStack {
                    
                    LazyHGrid(rows: rows, spacing: 7) {
                        
                        ForEach(colorToSelect, id: \.self) { color in
                            
                            Button {
                                colorSelect = color
                            } label: {
                                Circle()
                                    .frame(width: 22.5, height: 22.5)
                                    .foregroundColor(color)
                            }
                            
                        }
                        
                    }
                    
                    LazyVGrid(columns: columns, spacing: 20) {
                        
                        ForEach(symbolToSelect, id: \.self) { symbol in
                            
                            Button {
                                symbolSelect = symbol
                                presentationMode.wrappedValue.dismiss()
                            } label: {
                                Image(systemName: symbol)
                                    .foregroundColor(colorSelect)
                            }
                            
                        }
                        
                    }
                    
                    Spacer()
                }
                
            }
            
            .navigationTitle("Select color & symbol")
            .navigationBarTitleDisplayMode(.inline)
            .navigationBarItems(leading: cancelButton)
        }
        .navigationViewStyle(.stack)
        
    }
    
    var cancelButton: some View {
        Button {
            presentationMode.wrappedValue.dismiss()
        } label: {
            Text("Cancel")
                .foregroundColor(.blue)
        }
    }
    
}
