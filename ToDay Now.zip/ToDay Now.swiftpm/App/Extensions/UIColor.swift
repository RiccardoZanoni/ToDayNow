import SwiftUI

extension UIColor {
    
    var color: CIColor {
        return CIColor(color: self)
    }
    
    var components: (red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
        let uiColor = color.self
        return (uiColor.red, uiColor.green, uiColor.blue, uiColor.alpha)
    }
    
}
