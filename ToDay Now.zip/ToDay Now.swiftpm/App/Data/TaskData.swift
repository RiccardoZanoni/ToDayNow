import CoreData
import SwiftUI

@objc(TaskData)
class TaskData: NSManagedObject {
    @NSManaged var taskId: UUID
    @NSManaged var taskName: String
    @NSManaged var taskCategory: String
    @NSManaged var taskSubCategory: String
    @NSManaged var taskSymbol: String
    @NSManaged var taskColorRed: Float
    @NSManaged var taskColorGreen: Float
    @NSManaged var taskColorBlue: Float
    @NSManaged var taskColorAlpha: Float
    @NSManaged var taskPriorityNumber: Int
    @NSManaged var taskDate: Date
    @NSManaged var taskComplete: Bool
}

extension TaskData: Identifiable {
    
    var taskPriority: TaskPriority {
        get {
            TaskPriority(rawValue: Int(taskPriorityNumber)) ?? .normal
        }
        set {
            taskPriorityNumber = Int(newValue.rawValue)
        }
    }
    
}

enum TaskPriority: Int {
    
    case normal = 0
    case low = 1
    case medium = 2
    case high = 3
    
    func taskPriorityName() -> String {
        switch rawValue {
        case TaskPriority.normal.rawValue: 
            return "Normal"
        case TaskPriority.low.rawValue: 
            return "Low"
        case TaskPriority.medium.rawValue: 
            return "Medium"
        case TaskPriority.high.rawValue: 
            return "High"
        default: 
            return "Normal"
        }
    }
    
    func taskPriorityColor() -> Color {
        switch rawValue {
        case TaskPriority.normal.rawValue: 
            return .green
        case TaskPriority.low.rawValue: 
            return .yellow
        case TaskPriority.medium.rawValue: 
            return .orange
        case TaskPriority.high.rawValue: 
            return .red
        default: 
            return .green
        }
    }
    
    }
