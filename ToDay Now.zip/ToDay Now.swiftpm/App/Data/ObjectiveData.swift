import CoreData

@objc(ObjectiveData)
class ObjectiveData: NSManagedObject {
    @NSManaged var objectiveId: UUID
    @NSManaged var objectiveName: String
    @NSManaged var objectiveCategory: String
    @NSManaged var objectiveSubCategory: String
    @NSManaged var objectiveOnRemove: Float
    @NSManaged var objectiveOnAdd: Float
    @NSManaged var objectiveStatus: Float
    @NSManaged var objectiveOnRemoveTrim: Float
    @NSManaged var objectiveOnAddTrim: Float
    @NSManaged var objectiveStatusTrim: Float
    @NSManaged var objectiveEnd: Float
    @NSManaged var objectiveObject: String
    @NSManaged var objectiveSymbol: String
    @NSManaged var objectiveColorRed: Float
    @NSManaged var objectiveColorGreen: Float
    @NSManaged var objectiveColorBlue: Float
    @NSManaged var objectiveColorAlpha: Float
    @NSManaged var objectiveComplete: Bool
}

extension ObjectiveData: Identifiable {
}
