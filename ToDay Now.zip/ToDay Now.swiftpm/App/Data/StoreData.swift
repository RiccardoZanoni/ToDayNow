import CoreData

struct PersistenceController {
    static let shared = PersistenceController()
    
    static var preview: PersistenceController = {
        let result = PersistenceController(inMemory: true)
        let managedObjectContext = result.container.viewContext
        for i in 0 ..< 10 {
        }
        do {
            try managedObjectContext.save()
        } catch {
            let nsError = error as NSError
            print(nsError.localizedDescription)
        }
        return result
    }()
    
    let container: NSPersistentContainer
    
    init(inMemory: Bool = false) {
        
        let taskData = NSEntityDescription()
        taskData.name = "taskData"
        taskData.managedObjectClassName = "TaskData"
        
        let taskId = NSAttributeDescription()
        taskId.name = "taskId"
        taskId.type = .uuid
        taskData.properties.append(taskId)
        
        let taskName = NSAttributeDescription()
        taskName.name = "taskName"
        taskName.type = .string
        taskData.properties.append(taskName)
        
        let taskCategory = NSAttributeDescription()
        taskCategory.name = "taskCategory"
        taskCategory.type = .string
        taskData.properties.append(taskCategory)
        
        let taskSubCategory = NSAttributeDescription()
        taskSubCategory.name = "taskSubCategory"
        taskSubCategory.type = .string
        taskData.properties.append(taskSubCategory)
        
        let taskSymbol = NSAttributeDescription()
        taskSymbol.name = "taskSymbol"
        taskSymbol.type = .string
        taskData.properties.append(taskSymbol)
        
        let taskColorRed = NSAttributeDescription()
        taskColorRed.name = "taskColorRed"
        taskColorRed.type = .float
        taskData.properties.append(taskColorRed)
        
        let taskColorGreen = NSAttributeDescription()
        taskColorGreen.name = "taskColorGreen"
        taskColorGreen.type = .float
        taskData.properties.append(taskColorGreen)
        
        let taskColorBlue = NSAttributeDescription()
        taskColorBlue.name = "taskColorBlue"
        taskColorBlue.type = .float
        taskData.properties.append(taskColorBlue)
        
        let taskColorAlpha = NSAttributeDescription()
        taskColorAlpha.name = "taskColorAlpha"
        taskColorAlpha.type = .float
        taskData.properties.append(taskColorAlpha)
        
        let taskPriorityNumber = NSAttributeDescription()
        taskPriorityNumber.name = "taskPriorityNumber"
        taskPriorityNumber.type = .integer64
        taskData.properties.append(taskPriorityNumber)
        
        let taskDate = NSAttributeDescription()
        taskDate.name = "taskDate"
        taskDate.type = .date
        taskData.properties.append(taskDate)
        
        let taskComplete = NSAttributeDescription()
        taskComplete.name = "taskComplete"
        taskComplete.type = .boolean
        taskData.properties.append(taskComplete)
        
        let objectiveData = NSEntityDescription()
        objectiveData.name = "objectiveData"
        objectiveData.managedObjectClassName = "ObjectiveData"
        
        let objectiveId = NSAttributeDescription()
        objectiveId.name = "objectiveId"
        objectiveId.type = .uuid
        objectiveData.properties.append(objectiveId)
        
        let objectiveName = NSAttributeDescription()
        objectiveName.name = "objectiveName"
        objectiveName.type = .string
        objectiveData.properties.append(objectiveName)
        
        let objectiveCategory = NSAttributeDescription()
        objectiveCategory.name = "objectiveCategory"
        objectiveCategory.type = .string
        objectiveData.properties.append(objectiveCategory)
        
        let objectiveSubCategory = NSAttributeDescription()
        objectiveSubCategory.name = "objectiveSubCategory"
        objectiveSubCategory.type = .string
        objectiveData.properties.append(objectiveSubCategory)
        
        let objectiveOnRemove = NSAttributeDescription()
        objectiveOnRemove.name = "objectiveOnRemove"
        objectiveOnRemove.type = .float
        objectiveData.properties.append(objectiveOnRemove)
        
        let objectiveOnAdd = NSAttributeDescription()
        objectiveOnAdd.name = "objectiveOnAdd"
        objectiveOnAdd.type = .float
        objectiveData.properties.append(objectiveOnAdd)
        
        let objectiveStatus = NSAttributeDescription()
        objectiveStatus.name = "objectiveStatus"
        objectiveStatus.type = .float
        objectiveData.properties.append(objectiveStatus)
        
        let objectiveOnRemoveTrim = NSAttributeDescription()
        objectiveOnRemoveTrim.name = "objectiveOnRemoveTrim"
        objectiveOnRemoveTrim.type = .float
        objectiveData.properties.append(objectiveOnRemoveTrim)
        
        let objectiveOnAddTrim = NSAttributeDescription()
        objectiveOnAddTrim.name = "objectiveOnAddTrim"
        objectiveOnAddTrim.type = .float
        objectiveData.properties.append(objectiveOnAddTrim)
        
        let objectiveStatusTrim = NSAttributeDescription()
        objectiveStatusTrim.name = "objectiveStatusTrim"
        objectiveStatusTrim.type = .float
        objectiveData.properties.append(objectiveStatusTrim)
        
        let objectiveEnd = NSAttributeDescription()
        objectiveEnd.name = "objectiveEnd"
        objectiveEnd.type = .float
        objectiveData.properties.append(objectiveEnd)
        
        let objectiveObject = NSAttributeDescription()
        objectiveObject.name = "objectiveObject"
        objectiveObject.type = .string
        objectiveData.properties.append(objectiveObject)
        
        let objectiveSymbol = NSAttributeDescription()
        objectiveSymbol.name = "objectiveSymbol"
        objectiveSymbol.type = .string
        objectiveData.properties.append(objectiveSymbol)
        
        let objectiveColorRed = NSAttributeDescription()
        objectiveColorRed.name = "objectiveColorRed"
        objectiveColorRed.type = .float
        objectiveData.properties.append(objectiveColorRed)
        
        let objectiveColorGreen = NSAttributeDescription()
        objectiveColorGreen.name = "objectiveColorGreen"
        objectiveColorGreen.type = .float
        objectiveData.properties.append(objectiveColorGreen)
        
        let objectiveColorBlue = NSAttributeDescription()
        objectiveColorBlue.name = "objectiveColorBlue"
        objectiveColorBlue.type = .float
        objectiveData.properties.append(objectiveColorBlue)
        
        let objectiveColorAlpha = NSAttributeDescription()
        objectiveColorAlpha.name = "objectiveColorAlpha"
        objectiveColorAlpha.type = .float
        objectiveData.properties.append(objectiveColorAlpha)
        
        let objectiveComplete = NSAttributeDescription()
        objectiveComplete.name = "objectiveComplete"
        objectiveComplete.type = .boolean
        objectiveData.properties.append(objectiveComplete)
        
        let storeData = NSManagedObjectModel()
        storeData.entities = [taskData, objectiveData]
        
        container = NSPersistentContainer(name: "ToDay Now", managedObjectModel: storeData)
        
        if inMemory {
            container.persistentStoreDescriptions.first!.url = URL(fileURLWithPath: "/dev/null")
        }
        
        container.viewContext.automaticallyMergesChangesFromParent = true
        
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let nsError = error as NSError? {
                print(nsError.localizedDescription)
            }
        })
        
    }
    
}
