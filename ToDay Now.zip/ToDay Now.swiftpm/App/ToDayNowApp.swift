import SwiftUI

@main
struct ToDayNowApp: App {
    let persistenceController = PersistenceController.shared
    var body: some Scene {
        WindowGroup {
            TabItemsView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
